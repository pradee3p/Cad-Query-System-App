import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";

interface ThreeViewerProps {
  stlText: string;
  shadingMode: "solid" | "wireframe" | "transparent" | "xray";
  showGrid: boolean;
  showAxes: boolean;
  cameraView: "iso" | "top" | "front" | "right";
  onCameraViewReset?: () => void;
}

export default function ThreeViewer({
  stlText,
  shadingMode,
  showGrid,
  showAxes,
  cameraView,
  onCameraViewReset,
}: ThreeViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Three.js instances
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const meshRef = useRef<THREE.Mesh | null>(null);
  const gridHelperRef = useRef<THREE.GridHelper | null>(null);
  const axesHelperRef = useRef<THREE.AxesHelper | null>(null);
  const dirLightRef1 = useRef<THREE.DirectionalLight | null>(null);
  const dirLightRef2 = useRef<THREE.DirectionalLight | null>(null);

  // Drag controls state
  const isDragging = useRef(false);
  const previousMousePosition = useRef({ x: 0, y: 0 });
  const cameraRotation = useRef({ theta: Math.PI / 4, phi: Math.PI / 3, radius: 80 });
  const targetLookAt = useRef(new THREE.Vector3(0, 0, 0));

  // Initialize Three.js scene
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    // 1. Create Scene & Camera
    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#09090b"); // Premium zinc-950 background
    sceneRef.current = scene;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight || 450;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    cameraRef.current = camera;

    // 2. Create Renderer
    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      alpha: true,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    rendererRef.current = renderer;

    // 3. Add Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.45);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight1.position.set(50, 80, 50);
    scene.add(dirLight1);
    dirLightRef1.current = dirLight1;

    const dirLight2 = new THREE.DirectionalLight(0xa3b8cc, 0.4);
    dirLight2.position.set(-50, -30, -50);
    scene.add(dirLight2);
    dirLightRef2.current = dirLight2;

    // 4. Grid and Axes Helpers
    const gridHelper = new THREE.GridHelper(100, 50, "#06b6d4", "#27272a");
    gridHelper.rotation.x = Math.PI / 2; // CAD standard: XY plane is flat grid
    scene.add(gridHelper);
    gridHelperRef.current = gridHelper;

    const axesHelper = new THREE.AxesHelper(30);
    // CAD standard axes colors: X is Red, Y is Green, Z is Blue
    scene.add(axesHelper);
    axesHelperRef.current = axesHelper;

    // 5. Setup Camera Orbit positioning
    updateCameraPosition();

    // 6. Animation / Render loop
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);

      // Keep lights shining relative to the camera for perfect surface highlight
      if (cameraRef.current) {
        if (dirLightRef1.current) {
          dirLightRef1.current.position.copy(cameraRef.current.position);
        }
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(containerRef.current);

    return () => {
      cancelAnimationFrame(animationId);
      resizeObserver.disconnect();
      renderer.dispose();
    };
  }, []);

  // Update Camera View presets
  useEffect(() => {
    if (!cameraRef.current) return;

    const currentRadius = cameraRotation.current.radius;
    if (cameraView === "top") {
      cameraRotation.current = { theta: Math.PI / 2, phi: 0.01, radius: currentRadius };
    } else if (cameraView === "front") {
      cameraRotation.current = { theta: Math.PI / 2, phi: Math.PI / 2, radius: currentRadius };
    } else if (cameraView === "right") {
      cameraRotation.current = { theta: 0, phi: Math.PI / 2, radius: currentRadius };
    } else if (cameraView === "iso") {
      cameraRotation.current = { theta: Math.PI / 4, phi: Math.PI / 3, radius: currentRadius };
    }

    updateCameraPosition();
    if (onCameraViewReset) onCameraViewReset();
  }, [cameraView]);

  // Update Show/Hide Helpers
  useEffect(() => {
    if (gridHelperRef.current) {
      gridHelperRef.current.visible = showGrid;
    }
  }, [showGrid]);

  useEffect(() => {
    if (axesHelperRef.current) {
      axesHelperRef.current.visible = showAxes;
    }
  }, [showAxes]);

  // Parse and display the STL Mesh
  useEffect(() => {
    if (!sceneRef.current || !stlText) return;

    // Remove existing mesh
    if (meshRef.current) {
      sceneRef.current.remove(meshRef.current);
      meshRef.current.geometry.dispose();
      if (Array.isArray(meshRef.current.material)) {
        meshRef.current.material.forEach((m) => m.dispose());
      } else {
        meshRef.current.material.dispose();
      }
      meshRef.current = null;
    }

    try {
      // Parse ASCII STL
      const geometry = parseASCIIStl(stlText);
      if (!geometry || geometry.getAttribute("position").count === 0) return;

      // Select material based on shading mode
      let material: THREE.Material;

      const baseColor = "#06b6d4"; // Gorgeous CAD Cyan Shaded Blue

      if (shadingMode === "solid") {
        material = new THREE.MeshStandardMaterial({
          color: new THREE.Color(baseColor),
          roughness: 0.4,
          metalness: 0.35,
          side: THREE.DoubleSide,
        });
      } else if (shadingMode === "wireframe") {
        material = new THREE.MeshBasicMaterial({
          color: new THREE.Color(baseColor),
          wireframe: true,
        });
      } else if (shadingMode === "transparent") {
        material = new THREE.MeshStandardMaterial({
          color: new THREE.Color(baseColor),
          transparent: true,
          opacity: 0.5,
          roughness: 0.2,
          side: THREE.DoubleSide,
        });
      } else {
        // X-Ray styling
        material = new THREE.MeshStandardMaterial({
          color: new THREE.Color("#0891b2"),
          transparent: true,
          opacity: 0.35,
          wireframe: false,
          roughness: 0.1,
          metalness: 0.9,
          side: THREE.DoubleSide,
          emissive: new THREE.Color("#0891b2"),
          emissiveIntensity: 0.4,
        });
      }

      const mesh = new THREE.Mesh(geometry, material);
      sceneRef.current.add(mesh);
      meshRef.current = mesh;

      // Center and Auto-zoom to fit bounding box
      geometry.computeBoundingBox();
      const boundingBox = geometry.boundingBox;
      if (boundingBox) {
        const size = new THREE.Vector3();
        boundingBox.getSize(size);
        const center = new THREE.Vector3();
        boundingBox.getCenter(center);

        // Position the mesh at center
        targetLookAt.current.copy(center);

        // Adjust camera orbit radius depending on model dimensions
        const maxDim = Math.max(size.x, size.y, size.z);
        const fov = cameraRef.current?.fov || 45;
        let cameraDistance = maxDim / (2 * Math.tan((Math.PI * fov) / 360));
        cameraDistance = Math.max(cameraDistance * 1.8, 15); // safe padding

        cameraRotation.current.radius = cameraDistance;

        // Resize Grid to match bounding box nicely
        if (gridHelperRef.current) {
          sceneRef.current.remove(gridHelperRef.current);
          gridHelperRef.current.dispose();

          const gridSize = Math.max(maxDim * 3, 50);
          const gridDivs = Math.max(20, Math.floor(gridSize / 2));
          const gridHelper = new THREE.GridHelper(gridSize, gridDivs, "#3b82f6", "#1e293b");
          gridHelper.rotation.x = Math.PI / 2;
          // Place grid just below bounding box min Z
          gridHelper.position.z = boundingBox.min.z - 0.2;
          gridHelper.visible = showGrid;
          sceneRef.current.add(gridHelper);
          gridHelperRef.current = gridHelper;
        }

        updateCameraPosition();
      }
    } catch (e) {
      console.error("STL Rendering Error:", e);
    }
  }, [stlText, shadingMode]);

  // Helper to calculate orbital position of camera
  const updateCameraPosition = () => {
    const camera = cameraRef.current;
    if (!camera) return;

    const { theta, phi, radius } = cameraRotation.current;
    const target = targetLookAt.current;

    // Convert spherical coordinates to Cartesian
    const x = radius * Math.sin(phi) * Math.sin(theta);
    const y = radius * Math.sin(phi) * Math.cos(theta);
    const z = radius * Math.cos(phi);

    camera.position.set(x + target.x, y + target.y, z + target.z);
    camera.lookAt(target);
    camera.updateProjectionMatrix();
  };

  // Drag Orbit Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current) return;

    const deltaX = e.clientX - previousMousePosition.current.x;
    const deltaY = e.clientY - previousMousePosition.current.y;

    previousMousePosition.current = { x: e.clientX, y: e.clientY };

    // Standard orbit delta updates
    const speed = 0.007;
    cameraRotation.current.theta -= deltaX * speed;
    cameraRotation.current.phi -= deltaY * speed;

    // Constrain phi (elevation) to avoid flipping upside down
    cameraRotation.current.phi = Math.max(0.01, Math.min(Math.PI - 0.01, cameraRotation.current.phi));

    updateCameraPosition();
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    // Zoom in/out by adjusting orbit radius
    const zoomSpeed = 0.08;
    cameraRotation.current.radius += e.deltaY * zoomSpeed;
    cameraRotation.current.radius = Math.max(5, Math.min(300, cameraRotation.current.radius));

    updateCameraPosition();
  };

  // STL ASCII Parser
  function parseASCIIStl(text: string): THREE.BufferGeometry {
    const geometry = new THREE.BufferGeometry();
    const vertices: number[] = [];
    const normals: number[] = [];

    // Clean up text format
    const lines = text.split("\n");
    let currentNormal = [0, 0, 0];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      if (line.startsWith("facet normal")) {
        const parts = line.split(/\s+/);
        if (parts.length >= 5) {
          currentNormal = [
            parseFloat(parts[2]),
            parseFloat(parts[3]),
            parseFloat(parts[4]),
          ];
        }
      } else if (line.startsWith("vertex")) {
        const parts = line.split(/\s+/);
        if (parts.length >= 4) {
          vertices.push(
            parseFloat(parts[1]),
            parseFloat(parts[2]),
            parseFloat(parts[3])
          );
          normals.push(currentNormal[0], currentNormal[1], currentNormal[2]);
        }
      }
    }

    geometry.setAttribute("position", new THREE.BufferAttribute(new Float32Array(vertices), 3));
    geometry.setAttribute("normal", new THREE.BufferAttribute(new Float32Array(normals), 3));
    geometry.computeVertexNormals(); // Smooth out shading normals

    return geometry;
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full min-h-[400px] bg-[#0b0f19] rounded-xl overflow-hidden cursor-grab active:cursor-grabbing border border-slate-800"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onWheel={handleWheel}
      id="three-viewport-container"
    >
      <canvas ref={canvasRef} className="block w-full h-full" id="three-canvas" />

      {/* Orbit navigation guide overlay */}
      <div className="absolute bottom-3 left-3 bg-slate-900/80 backdrop-blur-md px-2 py-1 rounded text-[10px] text-slate-400 font-mono flex items-center gap-2 pointer-events-none border border-slate-800">
        <span>🖱️ Drag to Rotate</span>
        <span>•</span>
        <span>⚙️ Scroll to Zoom</span>
      </div>
    </div>
  );
}
