import { useState, useEffect, useRef } from "react";
import {
  Cpu,
  RotateCcw,
  Play,
  FileCode,
  Sliders,
  Maximize2,
  Download,
  Copy,
  Info,
  Terminal,
  Compass,
  FileDown,
  Sparkles,
  Layers,
  HelpCircle,
  Eye,
  Settings,
  AlertTriangle,
  Rotate3d,
} from "lucide-react";
import ThreeViewer from "./components/ThreeViewer";

interface Parameter {
  name: string;
  label: string;
  type: "float" | "int";
  default: number;
  min: number;
  max: number;
  description: string;
}

interface CADModel {
  title: string;
  explanation: string;
  python_code: string;
  parameters: Parameter[];
}

interface CADMetadata {
  volume: number;
  surface_area: number;
  bbox_min: number[];
  bbox_max: number[];
  vertices_count: number;
  faces_count: number;
}

// Initial design suggestion cards
const SUGGESTIONS = [
  {
    title: "Hexagonal Bolt",
    prompt: "A beautiful standard hex bolt with a 10mm thread diameter, 40mm shaft length, and 16mm head width.",
    icon: "🔩",
  },
  {
    title: "Mounting Bracket",
    prompt: "An L-shaped heavy duty mounting bracket of 50mm width, 50mm height, with two 8mm mounting holes.",
    icon: "📐",
  },
  {
    title: "Parametric Spur Gear",
    prompt: "A high-fidelity spur gear with 18 teeth, 40mm outer radius, 30mm inner core radius, and a 12mm central shaft bore.",
    icon: "⚙️",
  },
  {
    title: "Threaded Hex Nut",
    prompt: "A matching threaded hex nut for a 10mm bolt, with thickness 8mm and outer width 17mm.",
    icon: "🛑",
  },
];

export default function App() {
  // Query & Loading states
  const [prompt, setPrompt] = useState("");
  const [isQuerying, setIsQuerying] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // CAD Model States
  const [cadModel, setCadModel] = useState<CADModel | null>(null);
  const [parameters, setParameters] = useState<Record<string, number>>({});
  const [stlText, setStlText] = useState<string>("");
  const [metadata, setMetadata] = useState<CADMetadata | null>(null);

  // Editor State
  const [editableCode, setEditableCode] = useState("");
  const [activeTab, setActiveTab] = useState<"visuals" | "code">("visuals");

  // Visual Viewport settings
  const [shadingMode, setShadingMode] = useState<"solid" | "wireframe" | "transparent" | "xray">("solid");
  const [showGrid, setShowGrid] = useState(true);
  const [showAxes, setShowAxes] = useState(true);
  const [cameraView, setCameraView] = useState<"iso" | "top" | "front" | "right">("iso");

  // Copy/Download feedback states
  const [copiedStl, setCopiedStl] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  // Reference to hold previous parameter values to avoid duplicate calls
  const prevParamsRef = useRef<string>("");

  // Load a default model on startup
  useEffect(() => {
    handleQuery(SUGGESTIONS[0].prompt);
  }, []);

  // Run python execution when parameters change (debounced)
  useEffect(() => {
    if (!cadModel) return;

    const paramsStr = JSON.stringify(parameters);
    if (paramsStr === prevParamsRef.current) return;
    prevParamsRef.current = paramsStr;

    const timer = setTimeout(() => {
      executeCadScript(editableCode, parameters);
    }, 400); // 400ms debounce on parameter sliders

    return () => clearTimeout(timer);
  }, [parameters, cadModel, editableCode]);

  // Translate Natural Language query to CAD code via Gemini API on server
  const handleQuery = async (queryText: string) => {
    if (!queryText.trim()) return;
    setIsQuerying(true);
    setError(null);

    try {
      const res = await fetch("/api/cad/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: queryText }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to generate CAD code");
      }

      const data: CADModel = await res.json();
      setCadModel(data);
      setEditableCode(data.python_code);

      // Set default parameters
      const defaultParams: Record<string, number> = {};
      data.parameters.forEach((p) => {
        defaultParams[p.name] = p.default;
      });
      setParameters(defaultParams);

      // Execute the python script with the default parameters
      await executeCadScript(data.python_code, defaultParams);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during design generation.");
    } finally {
      setIsQuerying(false);
    }
  };

  // Run the Python script with parameter overrides
  const executeCadScript = async (code: string, params: Record<string, number>) => {
    setIsExecuting(true);
    setError(null);

    try {
      const res = await fetch("/api/cad/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, params }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.details || errData.error || "Python script execution failed");
      }

      const data = await res.json();
      if (data.stl) {
        // Base64 decode STL string
        const decodedStl = atob(data.stl);
        setStlText(decodedStl);
      }
      if (data.metadata) {
        setMetadata(data.metadata);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred while compiling your CAD script.");
    } finally {
      setIsExecuting(false);
    }
  };

  // Reset parameters back to default
  const resetParameters = () => {
    if (!cadModel) return;
    const defaultParams: Record<string, number> = {};
    cadModel.parameters.forEach((p) => {
      defaultParams[p.name] = p.default;
    });
    setParameters(defaultParams);
    setEditableCode(cadModel.python_code);
  };

  // Export functions
  const downloadSTLFile = () => {
    if (!stlText) return;
    const blob = new Blob([stlText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${cadModel?.title.replace(/\s+/g, "_") || "model"}.stl`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const copySTLToClipboard = () => {
    if (!stlText) return;
    navigator.clipboard.writeText(stlText);
    setCopiedStl(true);
    setTimeout(() => setCopiedStl(false), 2000);
  };

  const copyCodeToClipboard = () => {
    if (!editableCode) return;
    navigator.clipboard.writeText(editableCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-cyan-500/20 selection:text-cyan-200" id="app-root">
      {/* 1. Bento Header Section */}
      <header className="border-b border-zinc-800/80 bg-zinc-950/60 backdrop-blur-md px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-cyan-500 rounded flex items-center justify-center text-zinc-950 font-bold text-xl shadow-lg shadow-cyan-500/10">
            <Rotate3d className="h-6 w-6 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-zinc-100 font-display flex items-center gap-2">
              PyCAD <span className="text-zinc-500 font-normal">Query System</span>
              <span className="text-[10px] uppercase tracking-wider bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/20 font-mono font-bold">
                v2.4.0-stable
              </span>
            </h1>
            <p className="text-xs text-zinc-500 font-mono">
              Engine: Open CASCADE | Sandboxed Python Kernel
            </p>
          </div>
        </div>

        {/* Status Indicators */}
        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs flex items-center gap-2 font-mono text-zinc-300">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            <span>Kernel Ready</span>
          </div>
        </div>
      </header>

      {/* 2. Main Bento Grid Workspace */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto p-4 sm:p-6 grid grid-cols-12 gap-4">
        
        {/* ROW 1 / BLOCK 1: AI Prompt Compiler (col-span-4) */}
        <section className="col-span-12 lg:col-span-4 bg-zinc-900 border border-zinc-800 rounded-xl p-5 flex flex-col justify-between gap-4 shadow-xl relative overflow-hidden group">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-400 font-display">
              <Sparkles className="h-4 w-4 text-cyan-400" />
              <span>Ask Gemini to Create CAD</span>
            </div>

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleQuery(prompt);
              }}
              className="flex flex-col gap-3"
            >
              <div className="relative">
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g. A beautiful standard hex bolt with 10mm thread diameter, 40mm shaft length, and 16mm head width..."
                  className="w-full min-h-[100px] bg-zinc-950 rounded-lg p-3 text-sm text-zinc-200 border border-zinc-800 focus:border-cyan-500 focus:outline-none placeholder-zinc-600 transition resize-none font-sans"
                  disabled={isQuerying}
                />
                <button
                  type="submit"
                  disabled={isQuerying || !prompt.trim()}
                  className="absolute bottom-3 right-3 bg-cyan-600 hover:bg-cyan-500 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-medium text-xs px-4 py-2 rounded shadow-lg transition-all duration-200 flex items-center gap-1.5 border border-cyan-400/20 cursor-pointer"
                >
                  {isQuerying ? (
                    <>
                      <div className="animate-spin h-3.5 w-3.5 border-2 border-white border-t-transparent rounded-full" />
                      <span>Generating...</span>
                    </>
                  ) : (
                    <>
                      <Cpu className="h-3.5 w-3.5" />
                      <span>Compile CAD</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Suggested Chips */}
          <div className="flex flex-col gap-2 border-t border-zinc-800/80 pt-4 mt-2">
            <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold font-mono">
              Popular CAD Primitives
            </span>
            <div className="grid grid-cols-2 gap-2">
              {SUGGESTIONS.map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPrompt(s.prompt);
                    handleQuery(s.prompt);
                  }}
                  disabled={isQuerying}
                  className="flex items-center gap-2 text-left bg-zinc-950 hover:bg-zinc-800/80 active:bg-zinc-800 p-2 rounded-lg border border-zinc-800/60 transition group text-xs text-zinc-300 cursor-pointer"
                >
                  <span className="text-base group-hover:scale-110 transition">{s.icon}</span>
                  <span className="truncate font-medium">{s.title}</span>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* ROW 1 / BLOCK 2: 3D CAD Stage / Source Viewport (col-span-8) */}
        <section className="col-span-12 lg:col-span-8 bg-zinc-900 border border-zinc-800 rounded-xl p-4 flex flex-col gap-4 shadow-xl relative overflow-hidden">
          {/* Viewport & Tab Selector Header */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
            {/* Workspace Navigation Tabs */}
            <div className="bg-zinc-950 p-1 rounded-lg border border-zinc-800 flex gap-1">
              <button
                onClick={() => setActiveTab("visuals")}
                className={`px-4 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-2 cursor-pointer ${
                  activeTab === "visuals"
                    ? "bg-cyan-600 text-white shadow"
                    : "text-zinc-400 hover:text-white"
                }`}
              >
                <Eye className="h-3.5 w-3.5" />
                <span>3D CAD Stage</span>
              </button>
              <button
                onClick={() => setActiveTab("code")}
                className={`px-4 py-1.5 rounded-md text-xs font-medium transition flex items-center gap-2 cursor-pointer ${
                  activeTab === "code"
                    ? "bg-cyan-600 text-white shadow"
                    : "text-zinc-400 hover:text-white"
                }`}
              >
                <FileCode className="h-3.5 w-3.5" />
                <span>Python Source</span>
              </button>
            </div>

            {/* Shading/Render options (only shown when Active Tab is Visuals) */}
            {activeTab === "visuals" && (
              <div className="flex flex-wrap items-center gap-2">
                {/* Presets */}
                <div className="bg-zinc-950 p-1 rounded-lg border border-zinc-800 flex gap-1 text-[11px]">
                  <button
                    onClick={() => setCameraView("iso")}
                    className={`px-2.5 py-1 rounded transition cursor-pointer ${
                      cameraView === "iso" ? "bg-zinc-800 text-cyan-400 font-bold" : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    ISO
                  </button>
                  <button
                    onClick={() => setCameraView("top")}
                    className={`px-2.5 py-1 rounded transition cursor-pointer ${
                      cameraView === "top" ? "bg-zinc-800 text-cyan-400 font-bold" : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    TOP
                  </button>
                  <button
                    onClick={() => setCameraView("front")}
                    className={`px-2.5 py-1 rounded transition cursor-pointer ${
                      cameraView === "front" ? "bg-zinc-800 text-cyan-400 font-bold" : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    FRONT
                  </button>
                  <button
                    onClick={() => setCameraView("right")}
                    className={`px-2.5 py-1 rounded transition cursor-pointer ${
                      cameraView === "right" ? "bg-zinc-800 text-cyan-400 font-bold" : "text-zinc-400 hover:text-white"
                    }`}
                  >
                    SIDE
                  </button>
                </div>

                {/* Shading Dropdown */}
                <select
                  value={shadingMode}
                  onChange={(e: any) => setShadingMode(e.target.value)}
                  className="bg-zinc-950 text-zinc-300 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-cyan-500 font-medium cursor-pointer"
                >
                  <option value="solid">Shaded Solid</option>
                  <option value="wireframe">Wireframe</option>
                  <option value="transparent">Transparent</option>
                  <option value="xray">X-Ray Blueprint</option>
                </select>
              </div>
            )}
          </div>

          {/* TAB CONTENT 1: Visuals (3D Viewport) */}
          {activeTab === "visuals" && (
            <div className="relative flex-1 min-h-[420px] bg-zinc-950 rounded-lg border border-zinc-800/50 overflow-hidden">
              {stlText ? (
                <ThreeViewer
                  stlText={stlText}
                  shadingMode={shadingMode}
                  showGrid={showGrid}
                  showAxes={showAxes}
                  cameraView={cameraView}
                  onCameraViewReset={() => setCameraView("iso")}
                />
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-950 text-zinc-400 gap-3 [background-size:20px_20px] bg-[radial-gradient(#1e1e2e_1px,transparent_1px)]">
                  <div className="animate-spin h-8 w-8 border-4 border-cyan-500 border-t-transparent rounded-full" />
                  <span className="text-sm font-medium font-mono">Initializing 3D Stage...</span>
                </div>
              )}

              {/* Grid controls hover panel inside viewport */}
              <div className="absolute top-3 right-3 bg-zinc-900/95 backdrop-blur-md p-1.5 rounded-lg text-xs flex gap-3 text-zinc-300 border border-zinc-800 select-none">
                <label className="flex items-center gap-1.5 cursor-pointer hover:text-white transition">
                  <input
                    type="checkbox"
                    checked={showGrid}
                    onChange={(e) => setShowGrid(e.target.checked)}
                    className="accent-cyan-500 rounded"
                  />
                  <span>Grid</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer hover:text-white transition">
                  <input
                    type="checkbox"
                    checked={showAxes}
                    onChange={(e) => setShowAxes(e.target.checked)}
                    className="accent-cyan-500 rounded"
                  />
                  <span>Axes</span>
                </label>
              </div>

              {/* Loading indicator while rebuilding shape */}
              {isExecuting && (
                <div className="absolute top-3 left-3 bg-zinc-900/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-cyan-500/20 text-xs font-mono text-cyan-400 flex items-center gap-2 shadow-lg shadow-black/40">
                  <div className="animate-spin h-3.5 w-3.5 border-2 border-cyan-500 border-t-transparent rounded-full" />
                  <span>Compiling mesh...</span>
                </div>
              )}
            </div>
          )}

          {/* TAB CONTENT 2: Code Editor */}
          {activeTab === "code" && (
            <div className="flex flex-col gap-3 h-[420px]">
              <div className="flex items-center justify-between bg-zinc-950 p-2 rounded-lg border border-zinc-800 text-xs">
                <span className="text-zinc-400 flex items-center gap-1.5 font-mono">
                  <Terminal className="h-3.5 w-3.5 text-cyan-500" />
                  cad_script.py (Fully Editable)
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={copyCodeToClipboard}
                    className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded text-zinc-300 hover:text-white transition flex items-center gap-1.5 font-medium cursor-pointer text-xs"
                  >
                    <Copy className="h-3 w-3" />
                    <span>{copiedCode ? "Copied!" : "Copy Code"}</span>
                  </button>
                  <button
                    onClick={() => executeCadScript(editableCode, parameters)}
                    className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-bold transition flex items-center gap-1.5 shadow border border-cyan-400/20 cursor-pointer text-xs"
                  >
                    <Play className="h-3.5 w-3.5 fill-current" />
                    <span>Re-Run Script</span>
                  </button>
                </div>
              </div>

              <textarea
                value={editableCode}
                onChange={(e) => setEditableCode(e.target.value)}
                className="flex-1 w-full bg-zinc-950 text-zinc-100 font-mono text-xs p-4 rounded-lg border border-zinc-800 focus:outline-none focus:border-cyan-500/60 leading-relaxed resize-none overflow-y-auto"
              />
            </div>
          )}
        </section>

        {/* ROW 2 / BLOCK 3: Parametric Sliders (col-span-4) */}
        <section className="col-span-12 lg:col-span-4 bg-zinc-900 border border-zinc-800 rounded-xl p-5 flex flex-col justify-between gap-4 shadow-xl">
          <div>
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2 mb-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-400 font-display">
                <Sliders className="h-4 w-4 text-cyan-400" />
                <span>Parameters</span>
              </div>
              {cadModel && (
                <button
                  onClick={resetParameters}
                  className="text-[11px] text-zinc-400 hover:text-white flex items-center gap-1 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 px-2 py-0.5 rounded transition font-mono cursor-pointer"
                >
                  <RotateCcw className="h-3 w-3" />
                  <span>Reset Defaults</span>
                </button>
              )}
            </div>

            {/* Sliders Grid */}
            <div className="flex flex-col gap-3.5 max-h-[290px] overflow-y-auto pr-1">
              {cadModel ? (
                cadModel.parameters.map((param) => {
                  const val = parameters[param.name] ?? param.default;
                  return (
                    <div
                      key={param.name}
                      className="bg-zinc-950/60 p-3 rounded-lg border border-zinc-800/60 hover:border-zinc-800 transition"
                    >
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold text-zinc-300">{param.label}</span>
                        <span className="font-mono text-cyan-400 font-semibold bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20 text-[11px]">
                          {val}
                          <span className="text-[10px] text-zinc-400 ml-0.5">mm</span>
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-[10px] font-mono text-zinc-500 w-5">
                          {param.min}
                        </span>
                        <input
                          type="range"
                          min={param.min}
                          max={param.max}
                          step={param.type === "int" ? 1 : 0.5}
                          value={val}
                          onChange={(e) => {
                            setParameters({
                              ...parameters,
                              [param.name]: parseFloat(e.target.value),
                            });
                          }}
                          className="flex-1 accent-cyan-500 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                        />
                        <span className="text-[10px] font-mono text-zinc-500 w-7 text-right">
                          {param.max}
                        </span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-xs text-zinc-500 font-mono italic p-3 text-center">
                  No configurable parameters loaded.
                </div>
              )}
            </div>
          </div>

          <div className="text-[10px] text-zinc-500 font-mono border-t border-zinc-800/50 pt-2 text-right">
            Active: {Object.keys(parameters).length} dynamic nodes
          </div>
        </section>

        {/* ROW 2 / BLOCK 4: Explanation & Model Info (col-span-4) */}
        <section className="col-span-12 lg:col-span-4 bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-400 font-display">
                <Info className="h-4 w-4 text-cyan-400" />
                <span>Specs & Explanation</span>
              </div>
              <div className="text-[10px] text-cyan-400 font-mono bg-cyan-500/5 border border-cyan-500/15 px-2 py-0.5 rounded">
                ISO CAD Mode
              </div>
            </div>

            {cadModel ? (
              <>
                <h3 className="text-sm font-bold text-zinc-100 font-display">
                  {cadModel.title}
                </h3>
                <p className="text-xs text-zinc-400 leading-relaxed bg-zinc-950/40 p-3 rounded-lg border border-zinc-800/40 font-sans">
                  {cadModel.explanation}
                </p>
              </>
            ) : (
              <div className="text-xs text-zinc-500 font-mono italic p-3 text-center">
                Waiting for active design generation...
              </div>
            )}
          </div>

          <div className="text-[10px] text-zinc-500 font-mono border-t border-zinc-800/50 pt-2 flex justify-between">
            <span>Precision: High (CSG)</span>
            <span>Standard: ISO-7380</span>
          </div>
        </section>

        {/* ROW 2 / BLOCK 5: Geometry Dashboard (col-span-4) */}
        <section className="col-span-12 lg:col-span-4 bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-400 font-display">
                <Layers className="h-4 w-4 text-cyan-400" />
                <span>Geometrical Mesh Analysis</span>
              </div>
            </div>

            {metadata ? (
              <div className="grid grid-cols-2 gap-3 font-mono mt-1">
                <div className="bg-zinc-950/60 p-3 rounded-lg border border-zinc-800/50 text-center">
                  <div className="text-[9px] text-zinc-500 uppercase tracking-wider font-semibold">Volume</div>
                  <div className="text-base font-bold text-zinc-100 mt-0.5 truncate">
                    {metadata.volume.toLocaleString()} <span className="text-[9px] text-zinc-400 font-normal">mm³</span>
                  </div>
                </div>
                <div className="bg-zinc-950/60 p-3 rounded-lg border border-zinc-800/50 text-center">
                  <div className="text-[9px] text-zinc-500 uppercase tracking-wider font-semibold">Surface Area</div>
                  <div className="text-base font-bold text-zinc-100 mt-0.5 truncate">
                    {metadata.surface_area.toLocaleString()} <span className="text-[9px] text-zinc-400 font-normal">mm²</span>
                  </div>
                </div>
                <div className="bg-zinc-950/60 p-3 rounded-lg border border-zinc-800/50 text-center">
                  <div className="text-[9px] text-zinc-500 uppercase tracking-wider font-semibold">Faces/Triangles</div>
                  <div className="text-base font-bold text-zinc-100 mt-0.5 truncate">
                    {metadata.faces_count.toLocaleString()}
                  </div>
                </div>
                <div className="bg-zinc-950/60 p-3 rounded-lg border border-zinc-800/50 text-center flex flex-col justify-center">
                  <div className="text-[9px] text-zinc-500 uppercase tracking-wider font-semibold">Bounding Box</div>
                  <div className="text-[11px] font-bold text-zinc-200 mt-1 truncate">
                    {Math.round(metadata.bbox_max[0] - metadata.bbox_min[0])} × {Math.round(metadata.bbox_max[1] - metadata.bbox_min[1])} × {Math.round(metadata.bbox_max[2] - metadata.bbox_min[2])} <span className="text-[8px] text-zinc-500">mm</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-xs text-zinc-500 font-mono italic p-3 text-center">
                Render a 3D model to calculate geometry.
              </div>
            )}
          </div>

          <div className="text-[10px] text-zinc-500 font-mono border-t border-zinc-800/50 pt-2 text-right">
            Vertices: {metadata?.vertices_count ? metadata.vertices_count.toLocaleString() : "0"} total
          </div>
        </section>

        {/* BOTTOM SECTION / BLOCK 6: Exports, History, and Error Console (col-span-12) */}
        <section className="col-span-12 bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-xl flex flex-col gap-4">
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
            <div className="flex flex-col gap-1">
              <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider font-display">Export Manager & Workspace Actions</h3>
              <p className="text-[11px] text-zinc-500 font-mono">Format: Standard Stereolithography (.STL) | ASCII Format Spec 2.0</p>
            </div>

            {stlText && (
              <div className="flex gap-2">
                <button
                  onClick={copySTLToClipboard}
                  className="px-4 py-2 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 rounded-lg text-xs font-medium text-zinc-300 hover:text-white transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Copy className="h-3.5 w-3.5" />
                  <span>{copiedStl ? "Copied STL Text!" : "Copy STL Text"}</span>
                </button>
                <button
                  onClick={downloadSTLFile}
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-semibold shadow-md transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download STL Mesh</span>
                </button>
              </div>
            )}
          </div>

          {/* Bento Subgrid: Export History & Compile Errors */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Mock Export history list strictly matching bento mockups for ultra high-fidelity */}
            <div className="md:col-span-6 flex flex-col gap-2">
              <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-semibold font-mono">
                Recent Exports & Actions
              </span>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs p-2 bg-zinc-950/60 border border-zinc-800/80 rounded hover:border-zinc-800 transition">
                  <span className="text-zinc-300 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"></span>
                    {cadModel ? `${cadModel.title.replace(/\s+/g, "_").toLowerCase() || "model"}.stl` : "hexagonal_bolt.stl"}
                  </span>
                  <span className="text-zinc-600 font-mono text-[10px]">Just now</span>
                </div>
                <div className="flex items-center justify-between text-xs p-2 bg-zinc-950/20 border border-zinc-800/40 rounded opacity-60">
                  <span className="text-zinc-400 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-zinc-600 rounded-full"></span>
                    flange_adapter_v3.step
                  </span>
                  <span className="text-zinc-600 font-mono text-[10px]">2h ago</span>
                </div>
                <div className="flex items-center justify-between text-xs p-2 bg-zinc-950/20 border border-zinc-800/40 rounded opacity-60">
                  <span className="text-zinc-400 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-zinc-600 rounded-full"></span>
                    heavy_duty_mounting_bracket.stl
                  </span>
                  <span className="text-zinc-600 font-mono text-[10px]">5h ago</span>
                </div>
              </div>
            </div>

            {/* Error console or helpful tip */}
            <div className="md:col-span-6">
              {error ? (
                <div className="bg-red-950/20 rounded-lg border border-red-500/30 p-3 h-full flex flex-col gap-2">
                  <div className="flex items-center gap-2 text-red-400 text-xs font-bold font-mono">
                    <AlertTriangle className="h-4 w-4" />
                    <span>SANDBOX EXECUTION ERROR:</span>
                  </div>
                  <pre className="text-[10px] font-mono text-red-300/90 whitespace-pre-wrap bg-zinc-950/60 p-2 rounded border border-red-950/40 leading-relaxed overflow-y-auto max-h-[100px] flex-1">
                    {error}
                  </pre>
                </div>
              ) : (
                <div className="bg-zinc-950/40 rounded-lg border border-zinc-800/60 p-3 h-full flex flex-col justify-between text-xs text-zinc-500 font-mono">
                  <div className="flex items-start gap-2">
                    <Info className="h-4 w-4 text-cyan-500 shrink-0 mt-0.5" />
                    <p className="leading-relaxed">
                      All CAD models are rendered in real-time. Use the sliders above to adjust dimensions dynamically, or click <span className="text-zinc-300">Python Source</span> to edit scripts directly.
                    </p>
                  </div>
                  <div className="text-[10px] text-zinc-600 pt-2 border-t border-zinc-900 flex justify-between">
                    <span>DoubleSide Normal Shading: ON</span>
                    <span>STL ASCII: Enabled</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

      </main>

      {/* 3. Footer Bar */}
      <footer className="h-10 flex items-center justify-between text-[10px] text-zinc-600 border-t border-zinc-900 bg-zinc-950 px-6 font-mono mt-auto">
        <div className="flex gap-4">
          <span>Session: 8xf2-772a-cad-active</span>
          <span>GPU Sandbox Mode: Active</span>
        </div>
        <div className="flex gap-4">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-pulse"></span> 
            Trimesh Native CSG Mode
          </span>
          <span>UTF-8</span>
        </div>
      </footer>
    </div>
  );
}
